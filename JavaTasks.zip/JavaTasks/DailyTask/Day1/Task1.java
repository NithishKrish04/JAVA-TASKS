package Day1;
public class Task1{
public static void main( String args [] ){
System.out.println("ODD EVEN");
System.out.println("Enter a Number");
int a=0;
for (a=0;a<=100;a++){
 if (a%2==0){
System.out.println(a);
}}
}}
 
	 
