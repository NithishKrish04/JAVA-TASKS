package Day1;


public class Task2{
public static void main( String args [] ){
System.out.println("Simple Intrest Calculation");
int P=10000,T=1;
float R=5f,SI;
System.out.println("Principal Amount = ");
System.out.println("Rate of intrest per Year 1.6% ");
System.out.println("Period Of Loan = 5years");
SI=(P*R*T)/100;
System.out.println(SI);
}}